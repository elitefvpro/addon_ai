# ADDON AI v0.2 — base mobile/PWA

Esta versão prepara a interface mobile-first e a estrutura PWA para iPhone. **Ainda não é uma IA publicada nem um gerador completo de addons.**

## O que está incluído
- Interface adaptada a telas de iPhone.
- Manifesto PWA e registro de service worker.
- Endpoint de saúde `/api/health`.
- Endpoint `/api/chat` preparado para Anthropic, com chave mantida no servidor.
- Resposta explícita quando a chave não estiver configurada.

## O que ainda falta
- Publicar em hospedagem HTTPS.
- Configurar `ANTHROPIC_API_KEY` como variável secreta na hospedagem.
- Configurar autenticação/controle de acesso antes de abrir o serviço ao público.
- Banco de dados e armazenamento persistente.
- Geração e validação real de BP/RP, modelos, texturas, animações, scripts e `.mcaddon`.

## Desenvolvimento
Requer Node.js 18 ou superior:
1. `npm install`
2. Copie `.env.example` para `.env` e configure a chave somente em ambiente privado.
3. `npm run dev`

## Instalação no iPhone após publicar
1. Abra o endereço HTTPS no Safari.
2. Toque em Compartilhar.
3. Escolha **Adicionar à Tela de Início**.

A instalação PWA depende de publicação HTTPS. O projeto não foi testado em dispositivo real nesta entrega.
