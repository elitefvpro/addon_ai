import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "ADDON AI", version: "0.2.0" }));

app.post("/api/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim();
  if (!message) return res.status(400).json({ error: "Escreva uma mensagem." });
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(503).json({ error: "A API de IA ainda não foi configurada. Esta versão contém a interface e a estrutura do servidor." });
  }
  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-3-5-haiku-latest",
        max_tokens: 900,
        system: "Você é a ADDON AI, assistente especializada em criação de addons para Minecraft Bedrock. Responda em português brasileiro. Não afirme que gerou arquivos se não os gerou.",
        messages: [{ role: "user", content: message }]
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: data.error?.message || "Falha na API de IA." });
    const reply = (data.content || []).filter(x => x.type === "text").map(x => x.text).join("\n");
    return res.json({ reply });
  } catch {
    return res.status(502).json({ error: "Não foi possível conectar à API de IA." });
  }
});

const dist = path.resolve(__dirname, "../dist");
app.use(express.static(dist));
app.get("*", (_req, res) => res.sendFile(path.join(dist, "index.html")));
app.listen(PORT, () => console.log(`ADDON AI server listening on ${PORT}`));
