import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App() {
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState([{ role: "assistant", content: "Olá! Eu sou a ADDON AI. Em breve vou ajudar você a criar addons completos para Minecraft Bedrock. Esta é a estrutura inicial para iPhone." }]);
  const [status, setStatus] = useState("Conectando...");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/health").then(r => r.json()).then(() => setStatus("Interface conectada")).catch(() => setStatus("Modo demonstração — servidor ainda não publicado"));
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);

  async function send() {
    const text = prompt.trim();
    if (!text || busy) return;
    setMessages(m => [...m, { role: "user", content: text }]);
    setPrompt("");
    setBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      });
      const data = await response.json();
      setMessages(m => [...m, { role: "assistant", content: data.reply || data.error || "Não foi possível obter resposta." }]);
    } catch {
      setMessages(m => [...m, { role: "assistant", content: "O servidor ainda não está publicado. Quando conectarmos a hospedagem e a API de IA, o chat poderá responder." }]);
    } finally { setBusy(false); }
  }

  return <main className="app">
    <header className="top">
      <div className="logo">A<span>AI</span></div>
      <div><h1>ADDON AI</h1><p>Criador de addons para Minecraft Bedrock</p></div>
      <div className="status">{status}</div>
    </header>
    <section className="hero">
      <div className="eyebrow">MINECRAFT BEDROCK • IPHONE</div>
      <h2>Seu próximo addon começa aqui.</h2>
      <p>Descreva sua ideia. A ADDON AI será desenvolvida para transformar ideias em addons com comportamento, recursos e arquivos exportáveis.</p>
      <div className="chips"><span>Entidades</span><span>Modelos 3D</span><span>Texturas</span><span>Habilidades</span></div>
    </section>
    <section className="chat">
      <div className="chat-title"><div><b>Assistente ADDON AI</b><small>Ambiente de desenvolvimento</small></div><span className="online-dot"/></div>
      <div className="messages">{messages.map((m, i) => <div key={i} className={`bubble ${m.role}`}>{m.content}</div>)}</div>
      <div className="composer">
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="Descreva o addon que deseja criar..." rows="2"/>
        <button onClick={send} disabled={busy || !prompt.trim()}>{busy ? "..." : "Enviar"}</button>
      </div>
      <small className="hint">Versão inicial: o chat visual está pronto; a conexão real com IA será configurada na próxima etapa.</small>
    </section>
    <footer>ADDON AI • Projeto em desenvolvimento</footer>
  </main>;
}
createRoot(document.getElementById("root")).render(<App />);
